"use strict";
var util = require("gulp-util");
var helix = {};

helix.header = function header(line1, line2) {
util.log("O---o         ");
 
 util.log("O---o                                                            ");
util.log("O---o   | \ | |     /\     \ \    / / |  ____| |  ____| | \ | |   ");
util.log("O---o   |  \| |    /  \     \ \  / /  | |__    | |__    |  \| |   ");
util.log("O---o   | . ` |   / /\ \     \ \/ /   |  __|   |  __|   | . ` |   ");
util.log("O---o   | |\  |  / ____ \     \  /    | |____  | |____  | |\  |   ");
util.log("O---o   |_| \_| /_/    \_\     \/     |______| |______| |_| \_|   ");
util.log("O---o      ");
 

    util.log("  O    -------------------- https://www.m1.com.sg ------------------");
    util.log(" o-O   "); 
    util.log("o---O  " + line1);
    util.log("O---o  " + line2);
    util.log(" O-o   "); 
    util.log("  O    ----------------------------------------------------------");
    util.log(" o-O   ");
    util.log("o---O  ");
};

module.exports = helix;